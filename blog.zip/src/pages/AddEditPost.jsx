import React from 'react'

export const AddEditPost = () => {
  return (
    <div className='flex justify-start items-center pt-10 flex-col'>
      <p className='text-white text-3xl font-lonely'>Add Post</p>
      <hr className='border-stone-600 w-[400px] rounded-lg'/>
      <p className='text-stone-500 font-lonely'>Here you can add posts to the Firebase database.</p>
    </div>
  )
}