import React from 'react'

export const NotFound = () => {
  return (
    <div className='flex justify-center items-center min-h-screen'>
      <p className='text-black'>404</p>
    </div>
  )
}