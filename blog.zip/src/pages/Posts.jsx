import React from 'react'

export const Posts = () => {
  return (
    <div className='flex justify-start items-center pt-10 flex-col'>
    <p className='text-white text-3xl font-lonely'>Posts</p>
    <hr className='border-stone-600 w-[400px] rounded-lg'/>
    <p className='text-stone-500 font-lonely'>Here you can see the posts coming from the Firebase database.</p>
  </div>
  )
}