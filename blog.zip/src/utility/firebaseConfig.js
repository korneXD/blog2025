// Import the functions you need from the SDKs you need
// TODO: Add SDKs for Firebase products that you want to use

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyCfQ3hLtYDZrtMBZMGVO3BfK_OTa6xGvgE",
  authDomain: "blog-66660.firebaseapp.com",
  projectId: "blog-66660",
  storageBucket: "blog-66660.firebasestorage.app",
  messagingSenderId: "254484317361",
  appId: "1:254484317361:web:cb8e2e827b8577bee2ce90"
};

// Initialize Firebase